#include "TRhp.h"

TRhp::TRhp(){
    hp = 0;
}
int TRhp::getHp()
{
    return hp = gHero -> getHP();
}
